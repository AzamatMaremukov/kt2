def draw_box():
    print(int(input())* 7)
    for _ in range(5):
     print(int(input())* 7)

draw_box ()